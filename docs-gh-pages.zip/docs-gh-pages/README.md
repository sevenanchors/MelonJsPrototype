[melonJS](http://melonjs.org/) Documentation
===============================================================================

[http://melonjs.github.io/docs](http://melonjs.github.io/docs)

Questions, need help ?
-------------------------------------------------------------------------------
If you need help, you can try the [melonJS developer forum](http://groups.google.com/group/melonjs), or in #melonjs on irc.freenode.net.
For any other questions, feel free to send us an [email](mailto:contact@melonjs.org).


-------------------------------------------------------------------------------
Copyright (C) 2011 - 2013, Olivier Biot
melonJS is licensed under the [MIT License](http://www.opensource.org/licenses/mit-license.php)